#!/usr/bin/bash
sphinx-apidoc  -o . ../alamopy
